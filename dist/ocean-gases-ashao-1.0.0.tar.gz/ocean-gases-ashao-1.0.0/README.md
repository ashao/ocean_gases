# Ocean gases
A set of tools used to analyze oceanic trace gases. Includes routines for calculating solubilities, partial pressures, etc. for CFC-11, CFC-12, SF6


